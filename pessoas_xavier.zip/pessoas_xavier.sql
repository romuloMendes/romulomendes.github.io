-- MIGRACAO DE ALUNOS

CREATE TABLE escola_xavier ( id integer, codigo_matricula varchar(255), nome varchar(255), data_nascimento varchar(255), sexo varchar(255), mae varchar(255), cadastro_nacional varchar(255), local_nascimento varchar(255), email_comunicacao varchar(255), celular_comunicacao varchar(255), entidade_id varchar(255), created_at varchar(255), updated_at varchar(255));
COPY escola_xavier ( id codigo_matricula, nome, data_nascimento, sexo, mae, cadastro_nacional, local_nascimento, email_comunicacao, celular_comunicacao, entidade_id, created_at, updated_at) FROM '/home/romulo/www/aula/escola_xavier/escola_xavier.csv' DELIMITER ';' CSV HEADER;


CREATE TABLE pessoas (
	id serial primary key,
	codigo_matricula varchar(255),
	nome varchar(255),
	data_nascimento varchar(255),
	sexo varchar(255),
	mae varchar(255),
	cadastro_nacional varchar(255),
	local_nascimento varchar(255),
	email_comunicacao varchar(255),
	celular_comunicacao varchar(255),
	entidade_id varchar(255),
	created_at varchar(255),
	updated_at  varchar(255)
);


INSERT INTO pessoas (codigo_matricula, nome,  data_nascimento, sexo, mae, cadastro_nacional, local_nascimento, email_comunicacao, celular_comunicacao, entidade_id, created_at, updated_at)
SELECT
	codigo_matricula,
	nome,
	data_nascimento,
	sexo,
	mae,
	cadastro_nacional,
	local_nascimento,
	email_comunicacao,
	celular_comunicacao,
	entidade_id,
	created_at,
	updated_at
FROM escola_xavier;

ALTER TABLE escola_xavier ADD pessoa_id_proesc  varchar(255);
-- retorna os ides da tabele de pessoas rodado apos o insart
UPDATE escola_xavier SET pessoa_id_proesc=(SELECT pessoas.id FROM pessoas WHERE entidade_id = 2426 and pessoas.codigo_matricula is not null and pessoas.codigo_matricula=escola_xavier.codigo_matricula);


CREATE TABLE grupos_pessoas (
	grupo_id varchar(255),
	pessoa_id varchar(255),
	entidade_id varchar(255)
);


-- GRUPOS PESSOAS;
-- grupo_id=1 [Aluno]
-- grupo_id=2 [Funcionário]
-- grupo_id=3 [Professor]
-- grupo_id=4 [Responsável]
-- grupo_id=5 [Fornecedor]

INSERT INTO grupos_pessoas (grupo_id,pessoa_id,entidade_id)
SELECT 
    1 as grupo_id,
    pessoa_id_proesc:: integer as pessoa_id,
    2426 as entidade_id
FROM escola_xavier;

